import aiohttp
import asyncio
from fpl import FPL
import pandas as pd




async def main():
    async with aiohttp.ClientSession() as session:
        fpl = FPL(session)
        players = await fpl.get_players()
    
    team_mapping = {
            1: "Arsenal",
            2: "Aston Villa",
            3: "AFC Bournemouth",
            4: "Brentford",
            5: "Brighton & Hove Albion",
            6: "Chelsea",
            7: "Crystal Palace",
            8: "Everton",
            9: "Fulham",
            11: "Leeds United",
            10: "Leicester City",
            12: "Liverpool",
            13: "Manchester City",
            14: "Manchester United",
            15: "Newcastle United",
            16: "Nottingham Forest",
            17: "Southampton",
            18: "Tottenham Hotspur",
            19: "West Ham United",
            20: "Wolverhampton"
    }

    ls = []
    for player in players:
        #string = f"{player.id},{player.web_name},{player.first_name},{player.second_name},{player.team}\n"
        row = [player.id, player.web_name, player.first_name, player.second_name, player.team]
        ls.append(row)

    df = pd.DataFrame(ls, columns=['id', 'web_name', 'first name', 'last name', 'team_code'])
    df['team_name'] = df['team_code'].apply(lambda x: team_mapping[x])
    df['full_name'] = df[['first name', 'last name']].apply(lambda x: ' '.join(x), axis=1)
    print(df.sample(5))
    return df

    # text_file = open("Output.csv", "w")
    # text_file.writelines(ls)
    # text_file.close()
...
# Python 3.7+
#asyncio.run(main())